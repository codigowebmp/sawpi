<header>
    <h1>SAWPI</h1>
    <h2>Sistema de Administración Web Para Inmobiliaria</h2>
</header>  