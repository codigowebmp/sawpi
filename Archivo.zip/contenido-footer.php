SAWPI Inmobiliaria 2022 <br>
<?php echo $config['telefono1'] . " - " . $config['email_contacto'] ?>